package tk.ziniulian.job.rfid;

/**
 * 数据推送类型
 * Created by LZR on 2017/8/9.
 */

public enum EmPushMod {
	Event,	// 事件触发
	Catch,	// 记录标签集
	All
}
